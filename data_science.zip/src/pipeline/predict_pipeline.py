import os
import sys
import pandas as pd
from src.exception import CustomException
from src.logger import logging
from src.utils import load_object

# Project root (directory containing 'src' and 'artifacts') for reliable paths on EB
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class Customdata:
        def __init__(self,gender: str,race_ethnicity: str,parental_level_of_education: str,
            lunch:str, test_preparation_course: str,reading_score: int,writing_score: int):
            self.gender = gender
            self.race_ethnicity = race_ethnicity
            self.parental_level_of_education = parental_level_of_education
            self.lunch = lunch
            self.test_preparation_course = test_preparation_course
            self.reading_score = reading_score
            self.writing_score = writing_score
            
        def get_data_as_data_frame(self):
                custom_data_input_dict = {
                    "gender": [self.gender],
                    "race/ethnicity": [self.race_ethnicity],
                    "parental level of education": [self.parental_level_of_education],
                    "lunch": [self.lunch],
                    "test preparation course": [self.test_preparation_course],
                    "reading score": [self.reading_score],
                    "writing score": [self.writing_score]
                }
                return pd.DataFrame(custom_data_input_dict)

class PredictPipeline:
    def __init__(self):
        pass
    def predict(self, features):
        try:
            logging.info("Loading preprocessor and model objects")
            preprocessor_path = os.path.join(_PROJECT_ROOT, 'artifacts', 'preprocessor.pkl')
            model_path = os.path.join(_PROJECT_ROOT, 'artifacts', 'model.pkl')
            preprocessor = load_object(preprocessor_path)
            model = load_object(model_path)

            logging.info("Transforming features using preprocessor")
            data_scaled = preprocessor.transform(features)

            logging.info("Making predictions")
            preds = model.predict(data_scaled)
            return preds
        except Exception as e:
            logging.error("Error occurred during prediction")
            raise CustomException(e, sys)
        