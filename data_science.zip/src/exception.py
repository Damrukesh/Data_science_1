from src.logger import logging
import sys

def error_message_detail(error,error_detail:sys):
    _,_,exc_tb = error_detail.exc_info()
    line_number = exc_tb.tb_lineno
    file_name = exc_tb.tb_frame.f_code.co_filename
    error_msg = f"Error occurred in script: {file_name} at line number: {line_number} with error message: {str(error)}"
    file_name,exc_tb.tb_lineno,str(error) 
    return error_msg
    
class CustomException(Exception):
    def __init__(self,error_message,error_detail:sys):
        super().__init__(error_message)
        self.error_message = error_message_detail(error_message,error_detail=error_detail)

    def __str__(self):
        return self.error_message
    
if __name__ == "__main__":
    try:
        a = 4 / 0
    except Exception as e:
        logging.error("Exception occurred", exc_info=True)
        raise CustomException(e, sys)